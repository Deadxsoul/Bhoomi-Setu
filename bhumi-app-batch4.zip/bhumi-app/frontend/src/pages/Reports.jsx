import React from 'react';

export default function Reports() {
  function download(type) {
    const token = localStorage.getItem('bhumi_token');
    // Direct link download with token as query isn't ideal for prod;
    // for demo simplicity we fetch with auth header and trigger a blob download.
    fetch(`/api/reports/${type}`, { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => res.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = type === 'pdf' ? 'mis_report.pdf' : 'mis_report.xlsx';
        a.click();
        window.URL.revokeObjectURL(url);
      });
  }

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">📊 MIS Reports</h1>
      <p className="text-sm text-gray-500">Downloadable reports for officers — projects, parcels, and compensation summary.</p>

      <div className="card flex gap-4">
        <button className="btn-primary" onClick={() => download('pdf')}>⬇️ Download PDF Report</button>
        <button className="btn-secondary" onClick={() => download('excel')}>⬇️ Download Excel Report</button>
      </div>
    </div>
  );
}
