import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts';

const COLORS = ['#2563eb', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6'];

// Moved out of the navbar — this is now the "layer" of features that opens
// when you land on the Dashboard, instead of a permanent top-bar list.
const FEATURES = [
  { to: 'projects', label: 'Proposals', blurb: 'Submit & review project proposals' },
  { to: 'map', label: 'GIS Map', blurb: 'Parcel-level map with litigation risk' },
  { to: 'compensation', label: 'Compensation', blurb: 'Explainable compensation calculator' },
  { to: 'possession', label: 'Possession', blurb: 'Track possession status by parcel' },
  { to: 'rehabilitation', label: 'R&R', blurb: 'Rehabilitation & resettlement scoring' },
  { to: 'documents', label: 'Documents', blurb: 'Document management & duplicate check' },
  { to: 'satellite', label: 'Satellite Check', blurb: 'Encroachment detection' },
  { to: 'ranking', label: 'State Ranking', blurb: 'Gamified state-wise performance' },
  { to: 'chatbot', label: 'Farmer Chatbot', blurb: 'Guided help for farmers' },
  { to: 'reports', label: 'Reports', blurb: 'MIS reports — PDF & Excel' },
];

function FeatureGrid() {
  return (
    <div>
      <h2 className="text-lg font-display font-semibold text-ink mb-3">Explore</h2>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {FEATURES.map((f) => (
          <Link
            key={f.to}
            to={`/app/${f.to}`}
            className="bg-paper border border-stone rounded-xl p-4 hover:border-sage-3 hover:shadow-sm transition"
          >
            <div className="font-medium text-ink text-sm mb-1">{f.label}</div>
            <div className="text-xs text-ink-soft leading-snug">{f.blurb}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [stateWise, setStateWise] = useState([]);
  const [projectProgress, setProjectProgress] = useState([]);

  useEffect(() => {
    api.get('/dashboard/summary').then((r) => setSummary(r.data));
    api.get('/dashboard/state-wise').then((r) => setStateWise(r.data));
    api.get('/dashboard/project-progress').then((r) => setProjectProgress(r.data));
  }, []);

  if (!summary) return <div className="p-6">Loading dashboard…</div>;

  const kpis = [
    { label: 'Total Projects', value: summary.totalProjects },
    { label: 'Land Parcels', value: summary.totalParcels },
    { label: 'Possession Rate', value: `${summary.possessionRate}%` },
    { label: 'Compensation Disbursed', value: `${summary.compensationDisbursementRate}%` },
    { label: 'Families Resettled', value: `${summary.familiesResettled}/${summary.familiesTotal}` },
  ];

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <h1 className="text-2xl font-bold text-gray-800">National Dashboard</h1>

      <FeatureGrid />

      <h2 className="text-lg font-display font-semibold text-ink">Overview</h2>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {kpis.map((k) => (
          <div key={k.label} className="card text-center">
            <div className="text-2xl font-bold text-brand-700">{k.value}</div>
            <div className="text-xs text-gray-500 mt-1">{k.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="font-semibold mb-3">State-wise Compensation (Assessed vs Paid)</h2>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={stateWise}>
              <XAxis dataKey="state" fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip formatter={(v) => `₹${Number(v).toLocaleString('en-IN')}`} />
              <Legend />
              <Bar dataKey="total_compensation" name="Assessed" fill="#2563eb" />
              <Bar dataKey="paid_compensation" name="Paid" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h2 className="font-semibold mb-3">Parcels Possessed by State</h2>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={stateWise} dataKey="possessed_count" nameKey="state" outerRadius={100} label>
                {stateWise.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-3">Project-wise Progress</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500 border-b">
              <th className="py-2">Project</th>
              <th>State/District</th>
              <th>Status</th>
              <th>Parcels</th>
              <th>Possessed</th>
              <th>Compensated</th>
            </tr>
          </thead>
          <tbody>
            {projectProgress.map((p) => (
              <tr key={p.id} className="border-b last:border-0">
                <td className="py-2 font-medium">{p.name}</td>
                <td>{p.state}/{p.district}</td>
                <td className="capitalize">{p.status}</td>
                <td>{p.total_parcels}</td>
                <td>{p.possessed}</td>
                <td>{p.compensated}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
