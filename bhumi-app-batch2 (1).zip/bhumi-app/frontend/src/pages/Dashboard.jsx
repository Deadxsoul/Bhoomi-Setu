import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext.jsx';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/login');
  }

  const roleLabel = user?.guest
    ? t('dashboard.guest')
    : user?.role
    ? t(`roles.${user.role}`, user.role)
    : '';

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-paper border-b border-stone px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-moss/10 border border-moss/20 flex items-center justify-center">
            <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4">
              <path d="M3 21L12 3L21 21" stroke="#3B4630" strokeWidth="1.6" strokeLinejoin="round" />
              <path d="M8 21V13H16V21" stroke="#3B4630" strokeWidth="1.6" strokeLinejoin="round" />
            </svg>
          </div>
          <span className="font-display text-lg text-ink">{t('appName')}</span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex gap-1 text-sm">
            <button
              onClick={() => i18n.changeLanguage('en')}
              className={`px-2 py-1 rounded ${i18n.language === 'en' ? 'bg-stone font-medium text-ink' : 'text-ink-soft'}`}
            >
              English
            </button>
            <button
              onClick={() => i18n.changeLanguage('hi')}
              className={`px-2 py-1 rounded ${i18n.language === 'hi' ? 'bg-stone font-medium text-ink' : 'text-ink-soft'}`}
            >
              हिंदी
            </button>
          </div>
          <button
            onClick={handleLogout}
            className="text-sm px-3 py-1.5 rounded-lg border border-stone text-ink-soft hover:border-clay hover:text-clay-dark"
          >
            {t('dashboard.logout')}
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-14">
        <p className="text-sm text-ink-soft mb-1">
          {t('dashboard.role')}: <span className="text-ink font-medium">{roleLabel}</span>
        </p>
        <h1 className="font-display text-3xl text-ink mb-8">
          {t('dashboard.welcome')}{user?.name ? `, ${user.name}` : ''}
        </h1>

        <div className="bg-paper border border-stone rounded-2xl p-8">
          <h2 className="font-display text-xl text-ink mb-2">{t('dashboard.comingSoonTitle')}</h2>
          <p className="text-sm text-ink-soft leading-relaxed">{t('dashboard.comingSoonDesc')}</p>
        </div>
      </main>
    </div>
  );
}
