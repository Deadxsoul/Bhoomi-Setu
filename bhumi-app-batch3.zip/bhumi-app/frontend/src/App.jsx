import { Routes, Route, Navigate, Outlet } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Projects from './pages/Projects.jsx';
import MapView from './pages/MapView.jsx';
import Compensation from './pages/Compensation.jsx';
import Possession from './pages/Possession.jsx';
import Rehabilitation from './pages/Rehabilitation.jsx';
import Documents from './pages/Documents.jsx';
import Satellite from './pages/Satellite.jsx';
import StateRanking from './pages/StateRanking.jsx';
import Chatbot from './pages/Chatbot.jsx';
import Reports from './pages/Reports.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Navbar from './components/Navbar.jsx';

function AppLayout() {
  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-cream">
        <Navbar />
        <Outlet />
      </div>
    </ProtectedRoute>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Navigate to="/login" replace />} />

      <Route path="/app" element={<AppLayout />}>
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="projects" element={<Projects />} />
        <Route path="map" element={<MapView />} />
        <Route path="compensation" element={<Compensation />} />
        <Route path="possession" element={<Possession />} />
        <Route path="rehabilitation" element={<Rehabilitation />} />
        <Route path="documents" element={<Documents />} />
        <Route path="satellite" element={<Satellite />} />
        <Route path="ranking" element={<StateRanking />} />
        <Route path="chatbot" element={<Chatbot />} />
        <Route path="reports" element={<Reports />} />
      </Route>

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
